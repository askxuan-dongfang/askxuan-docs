# The Pictorial Key to the Tarot/Part 3 · 分段5/7

资料类别：古籍原文。专题：塔罗指引。
来源：古籍原文（历史观点，非实证结论）｜Arthur Edward Waite；1922重印本，初版1910；本批仅收文字｜https://en.wikisource.org/w/index.php?oldid=15274510｜en.wikisource.org贡献者｜CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0/｜采集2026-09-30；去网站导航、正文分段，保留原文；非影印校勘本

.—Sometimes denotes a woman of equivocal character.
Reversed:
A rich marriage for a man and a distinguished one for a woman.
Knight
.—A visit from a friend, who will bring unexpected money to the Querent.
Reversed:
Irregularity.
Page
.—Good augury; also a young man who is unfortunate in love.
Reversed:
Obstacles of all kinds.
Ten
.—For a male Querent, a good marriage and one beyond his expectations.
Reversed:
Sorrow; also a serious quarrel.
Nine
.—Of good augury for military men.
Reversed:
Good business.
Eight
.—Marriage with a fair woman.
Reversed:
Perfect satisfaction.
Seven
.—Fair child; idea, design, resolve, movement.
Reversed:
Success, if accompanied by the Three of Cups.
Six
.—Pleasant memories.
Reversed:
Inheritance to fall in quickly.
Five
.—Generally favourable; a happy marriage; also patrimony, legacies, gifts, success in enterprise.
Reversed:
Return of some relative who has not been seen for long.
Four
.—Contrarieties.
Reversed:
Presentiment.
Three
.—Unexpected advancement for military man.
Reversed:
Consolation, cure. end of the business.
Two
.—Favourable in things of pleasure and business, as well as love; also wealth and honour.
Reversed:
Passion.
Ace
.—Inflexible will, unalterable law.
Reversed:
Unexpected change of position.
Swords
.
King
.—A lawyer, senator, doctor.
Reversed:
A bad man; also a caution to put an end to a ruinous lawsuit.
Queen
.—A widow.
Reversed:
A bad woman, with ill-will towards the Querent.
Knight
.—A soldier, man of arms, satellite, stipendiary; heroic action predicted for soldier.
Reversed:
Dispute with an imbecile person; for a woman, struggle with a rival, who will be conquered.
Page
.—An indiscreet person will pry into the Querent's secrets.
Reversed:
Astonishing news.
Ten
.—Followed by Ace and King, imprisonment; for girl or wife, treason on the part of friends.
Reversed:
Victory and consequent fortune for a soldier in war.
Nine
.—An ecclesiastic, a priest; generally, a card of bad omen.
Reversed:
Good ground for suspicion against a doubtful person.
Eight
.—For a woman, scandal spread in her respect.
Reversed:
Departure of a relative.
Seven
.—Dark girl; a good card; it promises a country life after a competence has been secured.
Reversed:
Good advice, probably neglected.
Six
.—The voyage will be pleasant.
Reversed:
Unfavourable issue of lawsuit.
Five
.—An attack on the fortune of the
Querent.
Reversed:
A sign of sorrow and mourning.
Four
.—A bad card, but if reversed a qualified success may be expected by wise administration of affairs.
Reversed:
A certain success following wise administration.
Three
.—For a woman, the flight of her lover.
Reversed:
A meeting with one whom the Querent has compromised; also a nun.
Two
.—Gifts for a lady, influential protection for a man in search of help.
Reversed:
Dealings with rogues.
Ace
.—Great prosperity or great misery.
Reversed:
Marriage broken off, for a woman, through her own imprudence.
Pentacles
.
King
.—A rather dark man, a merchant, master, professor.
Reversed:
An old and vicious man.
Queen
.—Dark woman; presents from a rich relative; rich and happy marriage for a young man.
Reversed:
An illness.
Knight
.—An useful man; useful discoveries.
Reversed:
A brave man out of employment.
Page
.—A dark youth; a young officer or soldier; a child.
Reversed:
Sometimes degradation and sometimes pillage.
Ten
.—Represents house or dwelling, and de
rives its value from other cards.
Reversed:
An occasion which may be fortunate or otherwise.
Nine
.—Prompt fulfilment of what is presaged by neighbouring cards.
Reversed:
Vain hopes.
Eight
.—A young man in business who has relations with the Querent; a dark girl.
Reversed:
The Querent will be compromised in a matter of money-lending.
Seven
.—Improved position for a lady's future husband.
Reversed:
Impatience, apprehension, suspicion.
Six
.—The present must not be relied on.
Reversed:
A check on the Querent's ambition.
Five
.—Conquest of fortune by reason.
Reversed:
Troubles in love.
Four
.—For a bachelor, pleasant news from a lady.
Reversed:
Observation, hindrances.
Three
.—If for a man, celebrity for his eldest son.
Reversed:
Depends on neighbouring cards.
Two
.—Troubles are more imaginary than real.
Reversed:
Bad omen, ignorance, injustice.
Ace
.—The most favourable of all cards.
Reversed:
A share in the finding of treasure.
It will be observed (1) that these
additamenta
have little connexion with the pictorial de
signs of the cards to which they refer, as these correspond with the more important speculative values; (2) and further that the additional meanings are very often in disagreement with those previously given. All meanings are largely independent of one another and all are reduced, accentuated or subject to modification and sometimes almost reversal by their place in a sequence. There is scarcely any canon of criticism in matters of this kind. I suppose that in proportion as any system descends from generalities to details it becomes naturally the more precarious; and in the records of professional fortune-telling, it offers more of the dregs and
lees
of the subject. At the same time, divinations based on intuition and second sight are of little practical value unless they come down from the region of universals to that of particulars; but in proportion as this gift is present in a particular case, the specific meanings recorded by past cartomancists will be disregarded in favour of the personal appreciation of card values.
This has been intimated already. It seems necessary to add the following speculative readings.
§ 5
THE RECURRENCE OF CARDS IN DEALING
In the Natural Position
4 Kings = great honour; 3 Kings = consultation; 2 Kings = minor counsel.
4 Queens = great debate; 3 Queens = deception by women; 2 Queens = sincere friends.
4 Knights = serious matters; 3 Knights = lively debate; 2 Knights = intimacy.
4 Pages = dangerous illness; 3 Pages = dispute; 2 Pages = disquiet.
4 Tens = condemnation; 3 Tens = new condition; 2 Tens = change.
4 Nines = a good friend; 3 Nines = success; 2 Nines = receipt.
4 Eights = reverse; 3 Eights = marriage; 2 Eights = new knowledge.
4 Sevens = intrigue; 3 Sevens = infirmity; 2 Sevens = news.
4 Sixes = abundance; 3 Sixes = success; 2 Sixes = irritability.
4 Fives = regularity; 3 Fives = determination; 2 Fives = vigils.
4 Fours = journey near at hand; 3 Fours = a subject of reflection; 2 Fours = insomnia.
4 Threes = progress; 3 Threes = unity; 2 Threes = calm.
4 Twos = contention; 3 Twos = security; 2 Twos = accord.
4 Aces = favourable chance; 3 Aces = small success; 2 Aces = trickery.
Reversed
4 Kings = celerity; 3 Kings = commerce; 2 Kings = projects.
4 Queens = bad company; 3 Queens = gluttony; 2 Queens = work.
4 Knights = alliance; 3 Knights = a duel, or personal encounter; 2 Knights = susceptibility.
4 Pages = privation; 3 Pages = idleness; 2 Pages = society.
4 Tens = event, happening; 3 Tens = disappointment; 2 Tens = expectation justified.
4 Nines = usury; 3 Nines = imprudence; 2 Nines = a small profit.
4 Eights = error; 3 Eights = a spectacle; 2 Eights = misfortune.
4 Sevens = quarrellers; 3 Sevens = joy; 2 Sevens = women of no repute.
4 Sixes = care; 3 Sixes = satisfaction; 2 Sixes = downfall.
4 Fives = order; 3 Fives = hesitation; 2 Fives = reverse.
4 Fours = walks abroad; 3 Fours = disquiet; 2 Fours = dispute.
4 Threes = great success; 3 Threes = serenity; 2 Threes = safety.
4 Twos = reconciliation; 3 Twos = apprehension; 2 Twos = mistrust.
4 Aces = dishonour; 3 Aces = debauchery; 2 Aces = enemies.
§ 6
THE ART OF TAROT DIVINATION
We come now to the final and practical part of this division of our subject, being the way to consult and obtain oracles by means of Tarot cards. The modes of operation are rather numerous, and some of them are exceedingly involved. I set aside those last mentioned, because persons who are versed in such questions believe that the way of simplicity is the way of truth. I set aside also the operations which have been republished recently in that section of
The Tarot of the Bohemians
which is entitled "The Divining Tarot"; it may be recommended at its proper value to readers who wish to go further than the limits of this handbook. I offer in the first place a short process which has been used privately for many years past in England, Scotland and Ireland. I do not think that it has been published—certainly not in connexion with Tarot cards; I believe that it will serve all purposes, but I will add—by way of variation—in the second place what used to be known in France as the Oracles of Julia Orsini.
§ 7
An Ancient Celtic Method of Divination
This mode of divination is the most suitable for obtaining an answer to a definite question. The Diviner first selects a card to represent the person or matter about which inquiry is made. This card is called the Significator. Should he wish to ascertain something in connexion with himself he takes the one which corresponds to his personal description. A Knight should be chosen as the Significator if the subject of inquiry is a man of forty years old and upward; a King should be chosen for any male who is under that age; a Queen for a woman who is over forty years; and a Page for any female of less age.
The four Court Cards in Wands represent very fair people, with yellow or auburn hair, fair complexion and blue eyes. The Court Cards in Cups signify people with light brown or dull fair hair and grey or blue eyes. Those in Swords stand for people having hazel or grey eyes, dark brown hair and dull complexion. Lastly, the Court Cards in Penta
